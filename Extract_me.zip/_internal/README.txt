Created by Edgar A. Aguirre Castillo,  May 13th 2024. 

Make sure to have txMake available as a command on terminal, you can check if it works by running CMD and txmake.
 If installed correctly the help menu from txMake should be visible.
=================================================================================================
To install the variable on Windows:
-search modify environment variables with the windows taskbar searcher
-click on the advanced parameter tab
-click on environment variables
-Under system variables, click new...
-set variable name: RMANTREE
-set variable value: C:\Program Files\Pixar\RenderManProServer-26.0\ 
-click okay on all the windows

!!!! IMPORTANT !!!! the variable value might change with renderman version and with where was it installed.
=================================================================================================


try running again the txmake command on terminal



note this is a work in progress and it can be updated in the future to add advanced methods of txmake
